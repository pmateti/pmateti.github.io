/***** uno: uno_version.h *****/

static char *VERSION = "Version 2.13 - 26 October 2007";

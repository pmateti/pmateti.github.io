/***** uno: globals.h *****/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <errno.h>
#include "heap.h"
#include "treestk.h"

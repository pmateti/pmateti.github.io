object TestFactorial extends Application {
    def fact(n: Int): Int = {
        if (n == 0) 1 
        else n * fact(n-1)
    }
    
    println("The factorial of 8 is "+fact(8))
    // Output: The factorial of 8 is 40320
}

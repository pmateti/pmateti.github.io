import scala.actors.Actor
import scala.actors.Actor._

case class Msg1(value: Int)
case class Msg2(value: Int)
case class Response1(value: Int)
case class Response2(value: Int)

class ActorA extends Actor {
    var actorB: Actor = null

    def act() = {
        val value = 1

        println("A waiting for response 1")
        actorB !? Msg1(value) match {
            case Response1(r) => // ...
        }

        receive {
            case Msg2(value) => 
                reply(Response2(value))
                println("A got response!")
                exit()
        }
    }
}

class ActorB extends Actor {
    var actorA: Actor = null

    def act() = {
        val value = 1

        println("B waiting for response 2")
        actorA !? Msg2(value) match {
            case Response2(r) => // ...
        }

        receive {
            case Msg1(value) => 
                reply(Response1(value))
                println("B got response!")
                exit()
        }
    }
}

object ActorDeadlock extends Application {
    val actorA = new ActorA
    val actorB = new ActorB

    // Make sure they know eachother
    actorA.actorB = actorB
    actorB.actorA = actorA

    // Start the deadlock
    actorA.start()
    actorB.start()
}

-# Front Matter

# Dedications

*Ad Deum qui laetificat iuventutem meam.*

*To my beloved wife Monika.*


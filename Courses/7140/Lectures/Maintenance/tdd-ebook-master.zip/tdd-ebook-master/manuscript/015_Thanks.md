# Thanks!


I would like to thank the following people (listed alphabetically by name) for valuable feedback, suggestions, typo fixes and other contributions: 

-   Brad Appleton
-   Borysław Bobulski
-   Chris Kucharski
-   Daniel Dec
-   Daniel Żołopa (cover image)
-   Donghyun Lee
-   Łukasz Maternia
-   Marek Radecki
-   Martin Moene
-   Michael Whelan
-   Polina Kravchenko
-   Rafał Bigaj
-   Reuven Yagel
-   Rémi Goyard
-   Robert Pająk
-   Wiktor Żołnowski

This book is not original at all. It presents various topics that others invented and I just picked up. Thus, I would also like to thank my mentors and authorities on test-driven development and object-oriented design that I gained most of my knowledge from (listed alphabetically by name):

-   Amir Kolsky
-   Dan North
-   Emily Bache 
-   Ken Pugh
-   Kent Beck
-   Mark Seemann
-   Martin Fowler
-   Nat Pryce
-   Philip Schwarz
-   Robert C. Martin
-   Scott Bain
-   Steve Freeman
